﻿using System;
using System.Collections.Generic;
using System.Text;

namespace project_2
{
    interface ISaveToFile
    {
        StringBuilder GetString();
    }
}
